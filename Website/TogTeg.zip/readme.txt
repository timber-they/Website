--------------------------------------------------------------------

 This pack was composed using the ResourcePack Workbench (RPW).

    ____                                       ____             __
   / __ \___  _________  __  _______________  / __ \____ ______/ /__
  / /_/ / _ \/ ___/ __ \/ / / / ___/ ___/ _ \/ /_/ / __ `/ ___/ //_/
 / _, _/  __(__  ) /_/ / /_/ / /  / /__/  __/ ____/ /_/ / /__/ ,<
/_/ |_|\___/____/\____/\__,_/_/   \___/\___/_/    \__,_/\___/_/|_|
       _       __           __   __                    __
      | |     / /___  _____/ /__/ /_  ___  ____  _____/ /_
      | | /| / / __ \/ ___/ //_/ __ \/ _ \/ __ \/ ___/ __ \
      | |/ |/ / /_/ / /  / ,< / /_/ /  __/ / / / /__/ / / /
      |__/|__/\____/_/  /_/|_/_.___/\___/_/ /_/\___/_/ /_/

 RPW is open and free software, available under the MIT License.

--------------------------------------------------------------------

 [Get RPW] 
 
   * PlanetMinecraft  -> http://goo.gl/BwlCs
   * Minecraft Forum  -> http://goo.gl/ipbcH

 [Contribute] 
 
   * RPW on GitHub     -> https://github.com/MightyPork/rpw

 [Twitter] 
 
   * MightyPork    -> @MightyPork, <ondra@ondrovo.com>
   * RPW news      -> @RPWapp

--------------------------------------------------------------------

 Please, keep this file to give credit to RPW.

--------------------------------------------------------------------
